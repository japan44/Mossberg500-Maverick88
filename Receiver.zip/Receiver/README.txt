make sure printer is calibrated or reinforcement will not fit
print receiver front down, no supports, 0.12mm layer height, 10 walls 100% infill